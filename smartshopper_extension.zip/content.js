// content.js - SmartShopper AI Indian E-Commerce Scraper

const searchTriggers = ["q", "k", "field-keywords", "query", "search", "keyword"];

function extractStoreDetails() {
  const url = window.location.href;
  let store = "Unknown";
  let productTitle = "";
  let price = "";

  if (url.includes("flipkart.com")) {
    store = "Flipkart";
    const titleEl = document.querySelector("h1 span") || document.querySelector("._6EBuvd") || document.querySelector(".VU-ZEz") || document.querySelector(".B_NuCI");
    if (titleEl) productTitle = titleEl.innerText.trim();

    const priceEl = document.querySelector("._30jeq3") || document.querySelector(".Nx9bqj._4b5DiR") || document.querySelector(".Nx9bqj");
    if (priceEl) price = priceEl.innerText.trim();

  } else if (url.includes("amazon.in") || url.includes("amazon.com")) {
    store = "Amazon India";
    const titleEl = document.querySelector("#productTitle") || document.querySelector("#title");
    if (titleEl) productTitle = titleEl.innerText.trim();

    const priceEl = document.querySelector(".a-price-whole") || document.querySelector(".apexPriceToPay .a-offscreen") || document.querySelector(".a-price .a-offscreen");
    if (priceEl) price = priceEl.innerText.trim();

  } else if (url.includes("croma.com")) {
    store = "Croma";
    const titleEl = document.querySelector(".pdp-title") || document.querySelector("h1");
    if (titleEl) productTitle = titleEl.innerText.trim();

    const priceEl = document.querySelector(".amount") || document.querySelector(".pdp-price");
    if (priceEl) price = priceEl.innerText.trim();

  } else if (url.includes("myntra.com")) {
    store = "Myntra";
    const titleEl = document.querySelector(".pdp-title") || document.querySelector(".pdp-name");
    if (titleEl) productTitle = titleEl.innerText.trim();

    const priceEl = document.querySelector(".pdp-price");
    if (priceEl) price = priceEl.innerText.trim();
  }

  // Fallback if title not found
  if (!productTitle) {
    productTitle = extractSearchQuery() || document.title.split("|")[0].split("-")[0].trim();
  }

  return { store, productTitle, price, url };
}

function extractSearchQuery() {
  for (const name of searchTriggers) {
    const el = document.querySelector(`input[name="${name}"]`);
    if (el && el.value && el.value.length > 2) return el.value;
  }
  const urlParams = new URLSearchParams(window.location.search);
  for (const name of searchTriggers) {
    if (urlParams.has(name) && urlParams.get(name).length > 2) {
      return urlParams.get(name);
    }
  }
  return null;
}

function getUserId() {
  let userId = localStorage.getItem('smartshopper_user_id');
  if (!userId) {
    userId = 'cust_' + Math.floor(100 + Math.random() * 900);
    localStorage.setItem('smartshopper_user_id', userId);
  }
  return userId;
}

// High-Reliability Event Queue with Offline Persistence
async function sendEventToBackend(payload) {
  const backendUrls = [
    "http://localhost:8000/cluster-data",
    "https://crm-based-ecom.onrender.com/cluster-data"
  ];

  let delivered = false;
  for (const url of backendUrls) {
    try {
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
        signal: AbortSignal.timeout(2000)
      });
      if (res.ok) {
        delivered = true;
        break;
      }
    } catch (e) {
      // Try next endpoint
    }
  }

  // If network or server is offline, persist to local queue
  if (!delivered) {
    try {
      const queue = JSON.parse(localStorage.getItem('smartshopper_event_queue') || '[]');
      queue.push(payload);
      if (queue.length > 50) queue.shift(); // Keep latest 50
      localStorage.setItem('smartshopper_event_queue', JSON.stringify(queue));
    } catch (err) {}
  } else {
    // Flush pending offline queue if server is back
    flushOfflineEventQueue();
  }
}

async function flushOfflineEventQueue() {
  try {
    const queue = JSON.parse(localStorage.getItem('smartshopper_event_queue') || '[]');
    if (queue.length === 0) return;

    for (let i = 0; i < queue.length; i++) {
      await fetch("http://localhost:8000/cluster-data", {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(queue[i]),
        signal: AbortSignal.timeout(1500)
      }).catch(() => {});
    }
    localStorage.removeItem('smartshopper_event_queue');
  } catch (e) {}
}

window.addEventListener('online', flushOfflineEventQueue);

// Listen for analysis triggers from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === "start_deal_analysis") {
    const details = extractStoreDetails();
    const userId = getUserId();

    // Log analytics event
    sendEventToBackend({
      userId: userId,
      store: details.store,
      productTitle: details.productTitle,
      price: details.price,
      urlVisited: details.url,
      timestamp: new Date().toISOString()
    });

    // Request deals from background script
    chrome.runtime.sendMessage({
      type: "analyze_deals",
      query: details.productTitle || "popular electronics deal in India",
      sourceUrl: details.url,
      store: details.store,
      currentPrice: details.price,
      userId: userId
    }, (responseFromBackground) => {
      sendResponse(responseFromBackground);
    });

    return true; // Keep channel open for async response
  }
});
